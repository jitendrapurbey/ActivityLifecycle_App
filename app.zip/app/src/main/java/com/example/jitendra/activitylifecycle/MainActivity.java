package com.example.jitendra.activitylifecycle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private final String msg="Android:";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "Activity Created", Toast.LENGTH_SHORT).show();
        Log.d(msg,"The onCreate() event");

    }

    protected void onStart(){
        super.onStart();
        Toast.makeText(this, "Activity Started", Toast.LENGTH_SHORT).show();
        Log.d(msg,"The onStart() event");
    }

    protected void onPause(){
        super.onPause();
        Toast.makeText(this, "Activity Paused", Toast.LENGTH_SHORT).show();
        Log.d(msg,"The onPause() event");
    }

    protected void onRestart(){
        super.onRestart();
        Toast.makeText(this, "Activity Restarted", Toast.LENGTH_SHORT).show();
        Log.d(msg,"The onRestart() event");
    }

   protected void onStop(){
        super.onStop();
        Toast.makeText(this, "Activity Stopped", Toast.LENGTH_SHORT).show();
        Log.d(msg,"The onStop() event");
    }

   protected void onDestroy(){
        super.onDestroy();
        Toast.makeText(this, "Activity Destroyed", Toast.LENGTH_SHORT).show();
        Log.d(msg,"The onDestroy() event");
    }

    protected void onResume(){
        super.onResume();
        Toast.makeText(this, "Activity Resumed", Toast.LENGTH_SHORT).show();
        Log.d(msg,"The onResume() event");
    }


}
